
import java.util.ArrayList;

public class BubbleSort {

    
    /** 
     * @param v
     * @author Audrey Samantha Bhor López   
     * @version 1.0
     * @since 8-02-2023
     */
    public static void CBubbleSort(ArrayList<Integer> v) {
        boolean swiching = true;
        while (swiching) {
            swiching = false;
            for (int z = 0; z < v.size() - 1; z++) {
                if (v.get(z) > v.get(z + 1)) {
                    int temporal = v.get(z);
                    v.set(z, v.get(z + 1));
                    v.set(z + 1, temporal);
                    System.out.println("VS." + v);
                    swiching = true;
                }
            }
        }
    }
    
}
