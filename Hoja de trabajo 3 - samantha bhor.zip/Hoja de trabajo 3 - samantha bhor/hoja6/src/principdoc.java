import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/** 
     * @param args
     * @throws Exception
     * @author Audrey Samantha Bhor López   
     * @version 1.0
     * @since 8-02-2023
     */


public class principdoc extends comparat {

    static File archivo = new File("textos.txt");
    static ArrayList <Integer> numeros = new ArrayList<Integer>();

    
    /** 
     * @param args
     */
    public static void main(String[] args) {

        Random random = new Random();  
        int max = 0;
        int num = 100;
        clearFile();
        while (max != num){
            String x = (random.nextInt(2147483647) + "\n"); 
            max += 1;
            escribirArchivo(x);
        }
        numeros.removeAll(numeros);
        leerArchivo();
        System.out.println("\n");
        long start = System.nanoTime(); 
        ArrayList<Integer> Array1 = gnomeSort(numeros);   
        long elapsedTime = System.nanoTime() - start;
        System.out.println("Tiempo tomado por Gnome Sort: " + elapsedTime);
        for(int i=0;i<numeros.size();i++){
            System.out.println(numeros.get(i));
        } 
        numeros.removeAll(numeros);
        leerArchivo();
        System.out.println("\n");
        long startquick2 = System.nanoTime();
        ArrayList<Integer> Array2 = CQuickSort(numeros, 0, num-1);
        long elapsedTimequick2 = System.nanoTime() - startquick2;
        System.out.println("Tiempo tomado por Quick Sort: " + elapsedTimequick2);
        for(int i=0;i<numeros.size();i++){
            System.out.println(numeros.get(i));
        } 
        numeros.removeAll(numeros);
        leerArchivo();
        System.out.println("\n");
        long startbub = System.nanoTime();
        ArrayList<Integer> Array3 =  CBubbleSort(numeros); 
        long elapsedTimebub = System.nanoTime() - startbub; 
        System.out.println("Tiempo tomado por Bubble Sort: " + elapsedTimebub);
        for(int i=0;i<numeros.size();i++){
            System.out.println(numeros.get(i));
        } 
        numeros.removeAll(numeros);
        leerArchivo();
        System.out.println("\n");
        long startmerge = System.nanoTime();
        ArrayList<Integer> Array4 = mergeSort(numeros);
        long elapsedTimemerge = System.nanoTime() - startmerge;
        System.out.println("Tiempo tomado por Merge Sort: "+ elapsedTimemerge);
        for(int i=0;i<numeros.size();i++){
            System.out.println(numeros.get(i));
        }
        numeros.removeAll(numeros);
        leerArchivo();
        System.out.println("\n");
        long startRadix = System.nanoTime();
        ArrayList<Integer> Array5 = CRadixSort(numeros);;
        long elapsedTimerad = System.nanoTime() - startRadix;
        System.out.println("Tiempo tomado por Raidix Sort: "+ elapsedTimerad );
        for(int i=0;i<numeros.size();i++){
            System.out.println(numeros.get(i));

    }


     compareTo1(Array1, Array2);
     compareTo1(Array1, Array3);
     compareTo1(Array1, Array4);
     compareTo1(Array1, Array5);
     compareTo1(Array2, Array1);
     compareTo1(Array2, Array3);
     compareTo1(Array2, Array4);
     compareTo1(Array2, Array5);
     compareTo1(Array3, Array1);
     compareTo1(Array3, Array2);
     compareTo1(Array3, Array4);
     compareTo1(Array3, Array5);
     compareTo1(Array4, Array1);
     compareTo1(Array4, Array2);
     compareTo1(Array4, Array3);
     compareTo1(Array4, Array5);
     compareTo1(Array5, Array1);
     compareTo1(Array5, Array2);
     compareTo1(Array5, Array3);
     compareTo1(Array5, Array4);
     } 

    
    
    /** función de escribir rn archivo
     * @param info
     */
    private static void escribirArchivo(String info){
        try {
            FileWriter escribir = new FileWriter(archivo, true);
            escribir.write(info);
            escribir.close();
        }
        catch (Exception e) {
            System.out.println("Error de sintaxis");
        }
    }
    public static void clearFile()
    { 
        try{
        FileWriter fw = new FileWriter("textos.txt", false);
        PrintWriter pw = new PrintWriter(fw, false);
        pw.flush();
        pw.close();
        fw.close();
        }catch(Exception exception){
            System.out.println("Error");
        }
    }
    private static void leerArchivo(){
        String nombreFichero = "textos.txt";
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(nombreFichero));
            String texto = br.readLine();
            while(texto != null) {
                
                int num = Integer.parseInt(texto);
                numeros.add(num);
                texto = br.readLine();
            }
        }
        catch (FileNotFoundException ex) {
            System.out.println("");
            ex.printStackTrace();
        }
        catch(Exception ex) {
            System.out.println("");
            ex.printStackTrace();
        }
        finally {
            try {
                if(br != null) {
                    br.close();
                }
            }
            catch (Exception ex) {
                System.out.println("Error al cerrar el fichero");
                ex.printStackTrace();
            }
        }
    }

    
    /** 
     * @param list
     * @return ArrayList<Integer>
     */
    public static ArrayList<Integer> mergeSort(ArrayList<Integer> list) {
        MergeSort M = new MergeSort();
        
        ArrayList<Integer> anterior = new ArrayList<Integer>(){
        {
            add(5);
            add(8);
            add(15);
            add(45);
            add(56);
            add(78);
            add(112);
            add(75);
            add(48);
            add(18);
        }
        };

        ArrayList<Integer> ordenada = new ArrayList<Integer>(){
            {
                add(5);
                add(10);
                add(15);
                add(18);
                add(45);
                add(48);
                add(56);
                add(75);
                add(78);
                add(112);
            }
            };

            List<Integer> actual = M.ordenar(anterior);

            for (int i = 0; i < ordenada.size(); i++) {
                if (ordenada.get(i) != actual.get(i)) {
                    System.out.println("--> Error!, al ordenar lon números enteros");
                }
            }
            System.out.println("--> Exito!, al ordendar los números enteros");
            
            return list;
    }
    
    /** 
     * @param list
     * 
     */
    public static  ArrayList<Integer> gnomeSort(ArrayList<Integer> list) {
        int index = 0;
        while (index < list.size()) {
          if (index == 0 || list.get(index) >= list.get(index - 1)) {
            index++;
          } else {
            int temp = list.get(index);
            list.set(index, list.get(index - 1));
            list.set(index - 1, temp);
            index--;
          }
        }
        System.out.println("Se ordenaron correctamente");
        return list;
    }

    
    /** 
     * @param v
     * @param izq
     * @param der
     * 
     */
    public static ArrayList<Integer> CQuickSort(ArrayList<Integer> v, int izq, int der) {
        int pivote = v.get(izq);
        int i = izq;
        int j = der;// ultimo;
        int asistente;

        while (i < j) {
            while (v.get(i) <= pivote && i < j)
                i++;
            while (v.get(j) > pivote)
                j--;
            if (i < j) {
                asistente = v.get(i);
                
                v.set(i, v.get(j));
                v.set(j, asistente);

            }
        } 
        v.set(izq, v.get(j));
        v.set(j, pivote);

        if (izq < j - 1) {
            CQuickSort(v, izq, j - 1);
        }
        if (j + 1 < der) {
            CQuickSort(v, j + 1, der);
        }
        System.out.println("Se ordeno correctamente");
        return v;
    }
    
    /** 
     * @param v
     * @return ArrayList<Integer>
     */
    public static ArrayList<Integer> CBubbleSort(ArrayList<Integer> v) {
        boolean swiching = true;
        while (swiching) {
            swiching = false;
            for (int z = 0; z < v.size() - 1; z++) {
                if (v.get(z) > v.get(z + 1)) {
                    int temporal = v.get(z);
                    v.set(z, v.get(z + 1));
                    v.set(z + 1, temporal);
                    swiching = true;
                }
            }
        }
        System.out.println("Se ordeno correctamente");
        return v;
    }

    
    /** 
     * @param list
     */
    public static ArrayList<Integer> Crixsort(ArrayList<Integer> list){
        int[] data = { 121, 432, 564, 23, 1, 45, 788 };
        int size = data.length;
        rixsort rs = new rixsort();
        rs.radixSort(data, size);
        System.out.println("ordenados correctamente: ");
        System.out.println(Arrays.toString(data));
        return list;
      }

      
      /** 
       * @param v1
       * @param v2
       */
      private static void compareTo1(ArrayList<Integer> v1, ArrayList<Integer> v2) {
        comparat Comp = new comparat<>();
        boolean bandera = false;
    
        for (int i = 0; i < v1.size() - 1; i++) {
            for (int j = 0; j < v2.size() - 1; j++) {
                
            }

        }
        if (bandera == true) {
            System.out.println("Comparacion Exitosa");
        } else {
            System.out.println("No son Comparable");
        }

    }

    
}
