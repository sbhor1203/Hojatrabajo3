 /** 
     * @param v
     * @author Audrey Samantha Bhor López   
     * @version 1.0
     * @since 8-02-2023
     */

import java.util.ArrayList;
import java.util.List;

public class MergeSort {

    public List<Integer> ordenar(ArrayList<Integer> anterior) {

        return ordenarInterno(anterior, 0, anterior.size()-1);
    }

    /**
     * 
     * @param anterior
     * @param leftIndex
     * @param rightIndex
     * @return
     */
    private List<Integer> ordenarInterno(List<Integer> anterior, int leftIndex, int rightIndex){
        if (anterior.size() == 1) {
            return anterior;
        }
           int m = (int)Math.round((double)(leftIndex + (rightIndex))/2.0);
            
           List<Integer> left = new ArrayList<Integer>();
           List<Integer> right = new ArrayList<Integer>();

           for (int i = leftIndex; i <= rightIndex; i++) {
            if (i < m) {
                left.add(anterior.get(i));
            }else{
                right.add(anterior.get(i));
            }
           }
           left = ordenarInterno(left, 0, left.size()-1);
           right = ordenarInterno(right, 0, right.size()-1);
           
            List<Integer> leftRightUnion = new ArrayList<Integer>();
            
           int tamañoIzquierda = left.size();

            for (int i = 0; i < tamañoIzquierda;) {
                if (left.isEmpty()) {
                    leftRightUnion.addAll(right);
                    break;
                }
                if (right.isEmpty()) {
                    leftRightUnion.addAll(left);
                    break;
                }
                
                if (left.get(i) < right.get(i)) {
                    leftRightUnion.add(left.get(i));
                    left.remove(i);
                }else{
                    leftRightUnion.add(right.get(i));
                    right.remove(i);
                }
            } 

        return leftRightUnion;
    }
    
    
}
