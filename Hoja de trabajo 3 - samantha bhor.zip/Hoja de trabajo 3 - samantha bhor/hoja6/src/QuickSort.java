 /** 
     * @param v
     * @author Audrey Samantha Bhor López   
     * @version 1.0
     * @since 8-02-2023
     */


import java.util.ArrayList;
import java.util.Arrays;

public class QuickSort {
    ArrayList<Integer> vector1 = new ArrayList<Integer>(Arrays.asList(127137449, 504545637, 1898393767, 32616336,
            1464683277, 1118304394, 1414585023, 57038122, 222617213, 670861581));

    

    public static void CQuickSort(ArrayList<Integer> v, int izq, int der) {
        System.out.println("V." + v);
        System.out.println("izq" + izq);
        System.out.println("der" + der);

        int pivote = v.get(izq);
        int i = izq;// primero;
        int j = der;// ultimo;
        int asistente;

        while (i < j) {
            while (v.get(i) <= pivote && i < j)
                i++;
            while (v.get(j) > pivote)
                j--;
            if (i < j) {
                asistente = v.get(i);
                // vector1.get(i) = vector1.get(j);
                v.set(i, v.get(j));// = vector1.get(j);
                v.set(j, asistente);// = asistente;

            }
        }
        v.set(izq, v.get(j));
        v.set(j, pivote);

        if (izq < j - 1) {
            CQuickSort(v, izq, j - 1);
        }
        if (j + 1 < der) {
            CQuickSort(v, j + 1, der);
        }

        System.out.println("V." + v);

    }
    
}
