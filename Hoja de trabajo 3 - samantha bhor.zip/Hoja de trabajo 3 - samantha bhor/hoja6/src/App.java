public class App {
    
    /** 
     * @param args
     * @throws Exception
     * @author Audrey Samantha Bhor López   
     * @version 1.0
     * @since 8-02-2022
     */
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
    }
}
