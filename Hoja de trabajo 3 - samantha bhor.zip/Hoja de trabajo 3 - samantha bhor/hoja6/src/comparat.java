 /** 
     * @param v
     * @author Audrey Samantha Bhor López   
     * @version 1.0
     * @since 8-02-2023
     */
public class comparat<E> implements compararSecuen<E> {

    public int compareTo(E Array1,E Array2){
        int  A = Integer.parseInt(Array1.toString());
        int B = Integer.parseInt(Array2.toString());
        if( A > B){
            return 1;
        }else if(A < B){
            return -1;
        }else{
            return 0;
        }        
    }
    
}
