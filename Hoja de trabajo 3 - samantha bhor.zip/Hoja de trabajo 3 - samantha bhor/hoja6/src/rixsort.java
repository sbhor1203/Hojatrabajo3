 /** 
     * @param v
     * @author Audrey Samantha Bhor López   
     * @version 1.0
     * @since 8-02-2023
     */

public class rixsort {

    void Crixsort(int list[], int size, int place) {
        int[] output = new int[size + 1];
        int max = list[0];
        for (int i = 1; i < size; i++) {
          if (list[i] > max)
            max = list[i];
        }
        int[] count = new int[max + 1];
    
        for (int i = 0; i < max; ++i)
          count[i] = 0;
    
        for (int i = 0; i < size; i++)
          count[(list[i] / place) % 10]++;
 
        for (int i = 1; i < 10; i++)
          count[i] += count[i - 1];
    
        for (int i = size - 1; i >= 0; i--) {
          output[count[(list[i] / place) % 10] - 1] = list[i];
          count[(list[i] / place) % 10]--;
        }
    
        for (int i = 0; i < size; i++)
          list[i] = output[i];
      }
      int getMax(int list[], int n) {
        int max = list[0];
        for (int i = 1; i < n; i++)
          if (list[i] > max)
            max = list[i];
        return max;
      }
    
      void radixSort(int list[], int size) {
        int max = getMax(list, size);
    
        for (int place = 1; max / place > 0; place *= 10)
            Crixsort(list, size, place);
      }
    
    
}
